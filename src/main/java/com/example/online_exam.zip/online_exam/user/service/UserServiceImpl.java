package com.example.online_exam.user.service;

import com.example.online_exam.exception.AppException;
import com.example.online_exam.exception.ErrorCode;
import com.example.online_exam.secutity.service.CurrentUserService;
import com.example.online_exam.common.service.EmailService;
import com.example.online_exam.course.entity.Course;
import com.example.online_exam.course.repository.CourseRepository;
import com.example.online_exam.user.dto.CreateStudentRequest;
import com.example.online_exam.user.dto.CreateStudentResult;
import com.example.online_exam.user.dto.MyProfileResponse;
import com.example.online_exam.user.dto.UserRegisterRequest;
import com.example.online_exam.user.dto.UserResponse;
import com.example.online_exam.user.dto.UserUpdateRequest;
import com.example.online_exam.user.entity.Role;
import com.example.online_exam.user.entity.User;
import com.example.online_exam.user.enums.RoleName;
import com.example.online_exam.user.enums.UserStatus;
import com.example.online_exam.user.mapper.UserMapper;
import com.example.online_exam.user.repository.RoleRepository;
import com.example.online_exam.user.repository.UserRepository;
import com.example.online_exam.userprofile.dto.StudentProfileResponse;
import com.example.online_exam.userprofile.dto.StudentProfileUpdateRequest;
import com.example.online_exam.userprofile.dto.TeacherProfileResponse;
import com.example.online_exam.userprofile.dto.TeacherProfileUpdateRequest;
import com.example.online_exam.userprofile.entity.StudentProfile;
import com.example.online_exam.userprofile.entity.TeacherProfile;
import com.example.online_exam.userprofile.repository.StudentProfileRepository;
import com.example.online_exam.userprofile.repository.TeacherProfileRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
@Transactional
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;
    private final StudentProfileRepository studentProfileRepository;
    private final TeacherProfileRepository teacherProfileRepository;
    private final CurrentUserService currentUserService;
    private final CourseRepository courseRepository;

    // Optional — null nếu spring-boot-starter-mail chưa được cấu hình
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private EmailService emailService;

    @Override
    public UserResponse register(UserRegisterRequest request) {


        if (userRepository.existsByUsername(request.getUsername())) {
            throw new AppException(ErrorCode.USERNAME_EXISTS);
        }


        if (request.getEmail() != null &&
                userRepository.existsByEmail(request.getEmail())) {
            throw new AppException(ErrorCode.EMAIL_EXISTS);
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setFullName(request.getFullName());

        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));


        user.setStatus(UserStatus.ACTIVE);


        RoleName roleName = request.getRole() != null ? request.getRole() : RoleName.STUDENT;
        Role role = roleRepository.findByName(roleName)
                .orElseThrow(() -> new AppException(ErrorCode.INTERNAL_ERROR));

        user.setRoles(Set.of(role));

        userRepository.save(user);

        if(roleName == RoleName.STUDENT){
            StudentProfile profile = new StudentProfile();
            profile.setUser(user);
            studentProfileRepository.save(profile);
        }
        if(roleName == RoleName.TEACHER){
            TeacherProfile profile = new TeacherProfile();
            profile.setUser(user);
            teacherProfileRepository.save(profile);
        }
        return mapByVisibility(user);
//        return userMapper.toResponse(user);
//
    }

    @Override
    public UserResponse getById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));

        return mapByVisibility(user);
    }

    @Override
    public List<UserResponse> getAll() {
        return userRepository.findAll()
                .stream()
                .map(userMapper::toPrivateResponse)
                .toList();
    }
    @Override
    public MyProfileResponse getMyProfile() {
        User currentUser = currentUserService.requireCurrentUser();
        User user = userRepository.findById(currentUser.getId())
                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));

        MyProfileResponse response = new MyProfileResponse();
        response.setAccount(mapByVisibility(user));

        studentProfileRepository.findByUserId(user.getId())
                .ifPresent(profile -> {
                    StudentProfileResponse studentProfileResponse = new StudentProfileResponse();
                    studentProfileResponse.setStudentCode(profile.getStudentCode());
                    studentProfileResponse.setPhone(profile.getPhone());
                    studentProfileResponse.setDateOfBirth(profile.getDateOfBirth());
                    studentProfileResponse.setClassName(profile.getClassName());
                    response.setStudentProfile(studentProfileResponse);
                });

        teacherProfileRepository.findByUserId(user.getId())
                .ifPresent(profile -> {
                    TeacherProfileResponse teacherProfileResponse = new TeacherProfileResponse();
                    teacherProfileResponse.setTeacherCode(profile.getTeacherCode());
                    teacherProfileResponse.setPhone(profile.getPhone());
                    teacherProfileResponse.setDepartment(profile.getDepartment());
                    teacherProfileResponse.setSpecialization(profile.getSpecialization());
                    response.setTeacherProfile(teacherProfileResponse);
                });

        return response;
    }

    @Override
    public UserResponse update(Long id, UserUpdateRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));

        if (request.getEmail() != null && !request.getEmail().equals(user.getEmail())
                && userRepository.existsByEmail(request.getEmail())) {
            throw new AppException(ErrorCode.EMAIL_EXISTS);
        }

        if (request.getEmail() != null) {
            user.setEmail(request.getEmail());
        }

        if (request.getFullName() != null) {
            user.setFullName(request.getFullName());
        }

        if (request.getStatus() != null) {
            user.setStatus(request.getStatus());
        }

        userRepository.save(user);
        return mapByVisibility(user);
    }

    @Override
    public StudentProfileResponse updateMyStudentProfile(StudentProfileUpdateRequest request) {
        User currentUser = currentUserService.requireCurrentUser();
        if (!currentUserService.hasRole(currentUser, RoleName.STUDENT)) {
            throw new AppException(ErrorCode.FORBIDDEN);
        }

        StudentProfile profile = studentProfileRepository.findByUserId(currentUser.getId())
                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));

        // studentCode không cho phép tự sửa
        profile.setPhone(request.getPhone());
        profile.setDateOfBirth(request.getDateOfBirth());
        profile.setClassName(request.getClassName());
        studentProfileRepository.save(profile);

        StudentProfileResponse response = new StudentProfileResponse();
        response.setPhone(profile.getPhone());
        response.setDateOfBirth(profile.getDateOfBirth());
        response.setClassName(profile.getClassName());
        return response;
    }
    @Override
    public TeacherProfileResponse updateMyTeacherProfile(TeacherProfileUpdateRequest request) {
        User currentUser = currentUserService.requireCurrentUser();
        if (!currentUserService.hasRole(currentUser, RoleName.TEACHER)) {
            throw new AppException(ErrorCode.FORBIDDEN);
        }

        TeacherProfile profile = teacherProfileRepository.findByUserId(currentUser.getId())
                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));

        // teacherCode không cho phép tự sửa
        profile.setPhone(request.getPhone());
        profile.setDepartment(request.getDepartment());
        profile.setSpecialization(request.getSpecialization());
        teacherProfileRepository.save(profile);

        TeacherProfileResponse response = new TeacherProfileResponse();
        response.setPhone(profile.getPhone());
        response.setDepartment(profile.getDepartment());
        response.setSpecialization(profile.getSpecialization());
        return response;
    }
    @Override
    public void delete(Long id) {

        if (!userRepository.existsById(id)) {
            throw new AppException(ErrorCode.USER_NOT_FOUND);
        }
        studentProfileRepository.findByUserId(id).ifPresent(studentProfileRepository::delete);
        teacherProfileRepository.findByUserId(id).ifPresent(teacherProfileRepository::delete);
        userRepository.deleteById(id);
    }
    private UserResponse mapByVisibility(User targetUser) {
        User viewer = currentUserService.getCurrentUser().orElse(null);

        if (viewer == null) {
            // Chưa đăng nhập (vd: vừa register) → trả đủ info của chính user đó
            return userMapper.toRoleAwareResponse(targetUser, true, true);
        }

        boolean viewerIsAdmin = currentUserService.isAdmin(viewer);
        boolean viewerIsOwner = viewer.getId().equals(targetUser.getId());
        boolean includeSensitive = viewerIsAdmin || viewerIsOwner;
        boolean includeId = viewerIsAdmin || viewerIsOwner;

        return userMapper.toRoleAwareResponse(targetUser, includeSensitive, includeId);
    }
    @Override
    public List<UserResponse> getAllByRole(RoleName role) {
        return userRepository.findAll().stream()
                .filter(u -> u.getRoles().stream().anyMatch(r -> r.getName() == role))
                .map(userMapper::toPrivateResponse)
                .toList();
    }

    // ── Teacher tạo Student ───────────────────────────────

    @Override
    @Transactional
    public CreateStudentResult createStudent(CreateStudentRequest req) {
        // Kiểm tra username trùng
        if (userRepository.existsByUsername(req.getUsername())) {
            throw new AppException(ErrorCode.USERNAME_EXISTS);
        }

        // Tự sinh mật khẩu nếu không nhập
        String plainPwd = (req.getPassword() != null && !req.getPassword().isBlank())
                ? req.getPassword()
                : req.getUsername() + "123";

        // Tạo user
        User user = new User();
        user.setUsername(req.getUsername());
        user.setPasswordHash(passwordEncoder.encode(plainPwd));
        user.setEmail(req.getEmail() != null ? req.getEmail() : req.getUsername() + "@school.edu.vn");
        user.setFullName(req.getFullName());
        user.setStatus(UserStatus.ACTIVE);

        Role studentRole = roleRepository.findByName(RoleName.STUDENT)
                .orElseThrow(() -> new AppException(ErrorCode.ROLE_NOT_FOUND));
        user.setRoles(java.util.Set.of(studentRole));
        user = userRepository.save(user);

        // Tạo StudentProfile
        StudentProfile profile = new StudentProfile();
        profile.setUser(user);
        profile.setStudentCode(req.getStudentCode());
        profile.setClassName(req.getClassName());
        studentProfileRepository.save(profile);

        // Gắn vào lớp học nếu có courseId
        Long enrolledCourseId = null;
        if (req.getCourseId() != null) {
            Course course = courseRepository.findById(req.getCourseId())
                    .orElseThrow(() -> new AppException(ErrorCode.COURSE_NOT_FOUND));
            course.getStudents().add(user);
            courseRepository.save(course);
            enrolledCourseId = course.getId();
        }

        // Gửi email thông báo nếu có email thật và EmailService đã cấu hình
        final String finalPlainPwd = plainPwd;
        final Long finalEnrolledId = enrolledCourseId;
        final User savedUser = user;
        if (emailService != null
                && req.getEmail() != null
                && !req.getEmail().isBlank()
                && !req.getEmail().endsWith("@school.edu.vn")) {
            String courseName = null;
            if (enrolledCourseId != null) {
                courseName = courseRepository.findById(enrolledCourseId)
                        .map(c -> c.getName()).orElse(null);
            }
            emailService.sendStudentCredentials(
                    req.getEmail(),
                    user.getFullName(),
                    user.getUsername(),
                    plainPwd,
                    courseName
            );
        }

        return new CreateStudentResult(
                savedUser.getId(),
                savedUser.getUsername(),
                savedUser.getFullName(),
                savedUser.getEmail(),
                finalPlainPwd,
                req.getStudentCode(),
                req.getClassName(),
                finalEnrolledId
        );
    }

    // ── Password ──────────────────────────────────────────

    @Override
    public void changeMyPassword(String oldPassword, String newPassword) {
        User me = currentUserService.requireCurrentUser();
        if (!passwordEncoder.matches(oldPassword, me.getPasswordHash())) {
            throw new AppException(ErrorCode.INVALID_REQUEST); // Sai mật khẩu cũ
        }
        me.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepository.save(me);
    }

    @Override
    public void resetPassword(Long userId, String newPassword) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        // Gửi email thông báo nếu user có email thật
        if (emailService != null
                && user.getEmail() != null
                && !user.getEmail().endsWith("@school.edu.vn")) {
            emailService.sendPasswordReset(user.getEmail(), user.getFullName(), newPassword);
        }
    }

}
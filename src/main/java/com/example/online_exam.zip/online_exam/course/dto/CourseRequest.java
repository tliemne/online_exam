package com.example.online_exam.course.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CourseRequest {
    @NotBlank
    private String name;
    private String description;
    @NotNull
    private Long teacherId;
}
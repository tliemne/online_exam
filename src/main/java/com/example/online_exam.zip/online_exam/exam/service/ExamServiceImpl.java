package com.example.online_exam.exam.service;

import com.example.online_exam.course.entity.Course;
import com.example.online_exam.course.repository.CourseRepository;
import com.example.online_exam.exam.dto.*;
import com.example.online_exam.exam.entity.Exam;
import com.example.online_exam.exam.entity.ExamQuestion;
import com.example.online_exam.exam.enums.ExamStatus;
import com.example.online_exam.exam.repository.ExamQuestionRepository;
import com.example.online_exam.attempt.repository.AttemptRepository;
import com.example.online_exam.exam.repository.ExamRepository;
import com.example.online_exam.exception.AppException;
import com.example.online_exam.exception.ErrorCode;
import com.example.online_exam.question.entity.Answer;
import com.example.online_exam.question.entity.Question;
import com.example.online_exam.question.repository.QuestionRepository;
import com.example.online_exam.common.service.EmailService;
import com.example.online_exam.secutity.service.CurrentUserService;
import com.example.online_exam.user.entity.User;
import com.example.online_exam.user.enums.RoleName;
import com.example.online_exam.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class ExamServiceImpl implements ExamService {

    private final ExamRepository         examRepo;
    private final ExamQuestionRepository examQRepo;
    private final CourseRepository       courseRepo;
    private final QuestionRepository     questionRepo;
    private final UserRepository         userRepo;
    private final CurrentUserService     currentUserService;
    private final AttemptRepository      attemptRepo;
    private final EmailService            emailService;

    // ── Create ────────────────────────────────────────────
    @Override
    public ExamResponse create(ExamRequest req) {
        Course course = courseRepo.findById(req.getCourseId())
                .orElseThrow(() -> new AppException(ErrorCode.COURSE_NOT_FOUND));

        User creator = currentUser();

        // Teacher chỉ được tạo đề trong lớp của mình
        if (isTeacher(creator) && !isOwnerOfCourse(course, creator)) {
            throw new AppException(ErrorCode.FORBIDDEN);
        }

        Exam exam = new Exam();
        mapRequest(req, exam);
        exam.setCourse(course);
        exam.setCreatedBy(creator);
        exam = examRepo.save(exam);

        if (req.getQuestions() != null && !req.getQuestions().isEmpty()) {
            addQuestionsToExam(exam, req.getQuestions());
        }

        return toResponse(examRepo.findById(exam.getId()).orElseThrow(), true, false);
    }

    // ── Update ────────────────────────────────────────────
    @Override
    public ExamResponse update(Long id, ExamRequest req) {
        Exam exam = findExam(id);
        User caller = currentUser();

        // Teacher chỉ được sửa đề của mình
        if (isTeacher(caller)) {
            checkOwnership(exam, caller);
        }

        // Không cho sửa đề đã CLOSED (chỉ Admin mới được)
        // Không cho sửa đề đang PUBLISHED và còn hạn (đang diễn ra)
        if (exam.getStatus() == ExamStatus.PUBLISHED) {
            boolean stillActive = exam.getEndTime() == null
                    || exam.getEndTime().isAfter(java.time.LocalDateTime.now());
            if (stillActive && isTeacher(caller)) {
                throw new AppException(ErrorCode.INVALID_REQUEST);
            }
        }

        if (req.getCourseId() != null && !req.getCourseId().equals(exam.getCourse().getId())) {
            Course course = courseRepo.findById(req.getCourseId())
                    .orElseThrow(() -> new AppException(ErrorCode.COURSE_NOT_FOUND));
            // Teacher không được chuyển đề sang lớp của người khác
            if (isTeacher(caller) && !isOwnerOfCourse(course, caller)) {
                throw new AppException(ErrorCode.FORBIDDEN);
            }
            exam.setCourse(course);
        }

        mapRequest(req, exam);
        return toResponse(examRepo.save(exam), true, false);
    }

    // ── Delete ────────────────────────────────────────────
    @Override
    public void delete(Long id) {
        Exam exam = findExam(id);
        User caller = currentUser();

        if (isTeacher(caller)) {
            checkOwnership(exam, caller);
        }

        if (exam.getStatus() == ExamStatus.PUBLISHED) {
            boolean expired = exam.getEndTime() != null
                    && exam.getEndTime().isBefore(java.time.LocalDateTime.now());
            if (!expired) {
                throw new AppException(ErrorCode.INVALID_REQUEST);
            }
        }
        examRepo.delete(exam);
    }

    // ── Get ───────────────────────────────────────────────
    @Override
    @Transactional(readOnly = true)
    public ExamResponse getById(Long id, boolean includeQuestions, boolean hideCorrect) {
        Exam exam = findExam(id);
        User caller = currentUser();

        // Teacher chỉ được xem đề của mình
        if (isTeacher(caller)) {
            checkOwnership(exam, caller);
        }

        return toResponse(exam, includeQuestions, hideCorrect);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExamResponse> getAll() {
        User caller = currentUser();

        // Teacher chỉ thấy đề của mình
        if (isTeacher(caller)) {
            return examRepo.findByCreatedById(caller.getId()).stream()
                    .map(e -> toResponse(e, false, false)).collect(Collectors.toList());
        }

        // Admin thấy tất cả
        return examRepo.findAll().stream()
                .map(e -> toResponse(e, false, false)).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExamResponse> getByCourse(Long courseId) {
        User caller = currentUser();

        // Teacher chỉ thấy đề của mình trong lớp đó
        if (isTeacher(caller)) {
            return examRepo.findByCourseId(courseId).stream()
                    .filter(e -> e.getCreatedBy() != null && e.getCreatedBy().getId().equals(caller.getId()))
                    .map(e -> toResponse(e, false, false)).collect(Collectors.toList());
        }

        return examRepo.findByCourseId(courseId).stream()
                .map(e -> toResponse(e, false, false)).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExamResponse> getForStudent(Long studentId) {
        return examRepo.findPublishedForStudent(studentId).stream()
                .map(e -> {
                    ExamResponse r = toResponse(e, false, false);
                    long cnt = attemptRepo.countByExamIdAndStudentId(e.getId(), studentId);
                    r.setMyAttemptCount((int) cnt);
                    return r;
                })
                .collect(Collectors.toList());
    }

    // ── Manage questions ──────────────────────────────────
    @Override
    public ExamResponse addQuestion(Long examId, ExamQuestionItem item) {
        return addQuestions(examId, List.of(item));
    }

    @Override
    public ExamResponse addQuestions(Long examId, List<ExamQuestionItem> items) {
        Exam exam = findExam(examId);
        User caller = currentUser();
        if (isTeacher(caller)) checkOwnership(exam, caller);

        addQuestionsToExam(exam, items);
        return toResponse(examRepo.findById(examId).orElseThrow(), true, false);
    }

    @Override
    public ExamResponse removeQuestion(Long examId, Long questionId) {
        Exam exam = findExam(examId);
        User caller = currentUser();
        if (isTeacher(caller)) checkOwnership(exam, caller);

        examQRepo.deleteByExamIdAndQuestionId(examId, questionId);
        return toResponse(findExam(examId), true, false);
    }

    @Override
    public ExamResponse reorderQuestions(Long examId, List<ExamQuestionItem> items) {
        Exam exam = findExam(examId);
        User caller = currentUser();
        if (isTeacher(caller)) checkOwnership(exam, caller);

        List<ExamQuestion> eqs = examQRepo.findByExamIdOrderByOrderIndex(examId);
        for (ExamQuestionItem item : items) {
            eqs.stream()
                    .filter(eq -> eq.getQuestion().getId().equals(item.getQuestionId()))
                    .findFirst()
                    .ifPresent(eq -> {
                        eq.setOrderIndex(item.getOrderIndex());
                        if (item.getScore() != null) eq.setScore(item.getScore());
                    });
        }
        examQRepo.saveAll(eqs);
        return toResponse(findExam(examId), true, false);
    }

    // ── Publish / Close ───────────────────────────────────
    @Override
    public ExamResponse publish(Long id) {
        Exam exam = findExam(id);
        User caller = currentUser();
        if (isTeacher(caller)) checkOwnership(exam, caller);

        if (exam.getExamQuestions().isEmpty()) {
            throw new AppException(ErrorCode.INVALID_REQUEST); // Phải có ít nhất 1 câu
        }

        exam.setStatus(ExamStatus.PUBLISHED);
        ExamResponse response = toResponse(examRepo.save(exam), false, false);

        // Gửi email thông báo tới tất cả sinh viên trong lớp
        // Mỗi email dispatch vào emailExecutor thread pool riêng → không block HTTP
        if (exam.getCourse() != null && exam.getCourse().getStudents() != null) {
            String courseName = exam.getCourse().getName();
            exam.getCourse().getStudents().forEach(student -> {
                if (student.getEmail() != null) {
                    emailService.sendExamPublished(
                            student.getEmail(),
                            student.getFullName(),
                            exam.getTitle(),
                            courseName,
                            exam.getStartTime(),
                            exam.getEndTime(),
                            exam.getDurationMinutes()
                    );
                }
            });
        }

        return response;
    }

    @Override
    public ExamResponse close(Long id) {
        Exam exam = findExam(id);
        User caller = currentUser();
        if (isTeacher(caller)) checkOwnership(exam, caller);

        exam.setStatus(ExamStatus.CLOSED);
        return toResponse(examRepo.save(exam), false, false);
    }

    // ── Helpers ───────────────────────────────────────────

    /**
     * Kiểm tra teacher có phải chủ đề thi không, ném FORBIDDEN nếu không phải.
     */
    private void checkOwnership(Exam exam, User caller) {
        if (exam.getCreatedBy() == null || !exam.getCreatedBy().getId().equals(caller.getId())) {
            throw new AppException(ErrorCode.FORBIDDEN);
        }
    }

    /**
     * Kiểm tra teacher có phải chủ lớp không.
     */
    private boolean isOwnerOfCourse(Course course, User caller) {
        return course.getTeacher() != null && course.getTeacher().getId().equals(caller.getId());
    }

    /**
     * Trả true nếu user là TEACHER (không phải ADMIN).
     */
    private boolean isTeacher(User user) {
        return user.getRoles().stream()
                .anyMatch(r -> r.getName() == RoleName.TEACHER);
    }

    private void mapRequest(ExamRequest req, Exam exam) {
        if (req.getTitle() != null)           exam.setTitle(req.getTitle());
        if (req.getDescription() != null)     exam.setDescription(req.getDescription());
        if (req.getDurationMinutes() != null) exam.setDurationMinutes(req.getDurationMinutes());
        if (req.getStartTime() != null)       exam.setStartTime(req.getStartTime());
        if (req.getEndTime() != null)         exam.setEndTime(req.getEndTime());
        exam.setTotalScore(req.getTotalScore() != null ? req.getTotalScore() : 10.0);
        exam.setPassScore(req.getPassScore() != null ? req.getPassScore() : 5.0);
        exam.setRandomizeQuestions(req.getRandomizeQuestions() != null && req.getRandomizeQuestions());
        exam.setMaxAttempts(req.getMaxAttempts() != null ? req.getMaxAttempts() : 1);
        exam.setAllowResume(req.getAllowResume() != null ? req.getAllowResume() : false);
    }

    private void addQuestionsToExam(Exam exam, List<ExamQuestionItem> items) {
        int currentMax = exam.getExamQuestions().size();
        List<ExamQuestion> toAdd = new ArrayList<>();

        for (int i = 0; i < items.size(); i++) {
            ExamQuestionItem item = items.get(i);
            if (examQRepo.existsByExamIdAndQuestionId(exam.getId(), item.getQuestionId()))
                continue;

            Question q = questionRepo.findById(item.getQuestionId())
                    .orElseThrow(() -> new AppException(ErrorCode.QUESTION_NOT_FOUND));

            ExamQuestion eq = new ExamQuestion();
            eq.setExam(exam);
            eq.setQuestion(q);
            eq.setScore(item.getScore() != null ? item.getScore() : 1.0);
            eq.setOrderIndex(item.getOrderIndex() != null ? item.getOrderIndex() : currentMax + i);
            toAdd.add(eq);
        }
        examQRepo.saveAll(toAdd);
    }

    private ExamResponse toResponse(Exam exam, boolean includeQuestions, boolean hideCorrect) {
        ExamResponse r = new ExamResponse();
        r.setId(exam.getId());
        r.setTitle(exam.getTitle());
        r.setDescription(exam.getDescription());
        r.setDurationMinutes(exam.getDurationMinutes());
        r.setStartTime(exam.getStartTime());
        r.setEndTime(exam.getEndTime());
        r.setTotalScore(exam.getTotalScore());
        r.setPassScore(exam.getPassScore());
        r.setRandomizeQuestions(exam.getRandomizeQuestions());
        r.setMaxAttempts(exam.getMaxAttempts());
        r.setAllowResume(exam.getAllowResume() != null ? exam.getAllowResume() : false);
        r.setStatus(exam.getStatus());
        r.setCreatedAt(exam.getCreatedAt());

        if (exam.getCourse() != null) {
            r.setCourseId(exam.getCourse().getId());
            r.setCourseName(exam.getCourse().getName());
        }
        if (exam.getCreatedBy() != null)
            r.setCreatedByName(exam.getCreatedBy().getFullName());

        r.setQuestionCount(exam.getExamQuestions().size());

        if (includeQuestions) {
            r.setQuestions(exam.getExamQuestions().stream()
                    .map(eq -> toExamQResponse(eq, hideCorrect))
                    .collect(Collectors.toList()));
        }
        return r;
    }

    private ExamQuestionResponse toExamQResponse(ExamQuestion eq, boolean hideCorrect) {
        Question q = eq.getQuestion();
        ExamQuestionResponse r = new ExamQuestionResponse();
        r.setId(eq.getId());
        r.setQuestionId(q.getId());
        r.setContent(q.getContent());
        r.setType(q.getType());
        r.setDifficulty(q.getDifficulty());
        r.setScore(eq.getScore());
        r.setOrderIndex(eq.getOrderIndex());

        r.setAnswers(q.getAnswers().stream().map(a -> {
            ExamQuestionResponse.AnswerInExam ai = new ExamQuestionResponse.AnswerInExam();
            ai.setId(a.getId());
            ai.setContent(a.getContent());
            ai.setCorrect(hideCorrect ? null : a.isCorrect());
            return ai;
        }).collect(Collectors.toList()));

        return r;
    }

    private Exam findExam(Long id) {
        return examRepo.findById(id)
                .orElseThrow(() -> new AppException(ErrorCode.EXAM_NOT_FOUND));
    }

    private User currentUser() {
        return currentUserService.requireCurrentUser();
    }
}